


import json
import urllib
import os
import datetime
import sys, os.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname( __file__ ), 'env/Lib/site-packages')))
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests

# postreqdata = json.loads(open(os.environ['req']).read())

# response = open(os.environ['res'], 'w')

batch_index = 'batch-metadata'
stream_index = 'stream-metadata'

batchDashboardJSON= [
                      {
                        "_id": "Batch-Data-Lake-Metadata",
                        "_type": "dashboard",
                        "_source": {
                          "title": "Batch Data Lake Metadata",
                          "hits": 0,
                          "description": "",
                          "panelsJSON": "[{\"col\":1,\"id\":\"Raw-Size\",\"panelIndex\":1,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":4,\"id\":\"Transformed-Datasets-Size\",\"panelIndex\":2,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":7,\"id\":\"Published-Data-Size\",\"panelIndex\":3,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":10,\"id\":\"Combined-Size\",\"panelIndex\":4,\"row\":1,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":1,\"id\":\"Raw-Count\",\"panelIndex\":5,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":4,\"id\":\"Transformed-Datasets-Count\",\"panelIndex\":6,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":7,\"id\":\"Published-Data-Count\",\"panelIndex\":7,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":10,\"id\":\"Combined-Count\",\"panelIndex\":8,\"row\":3,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":1,\"id\":\"Top-Raw-Summary\",\"panelIndex\":9,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":4,\"id\":\"Top-Transformed-Datasets-Summary\",\"panelIndex\":10,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":7,\"id\":\"Top-Published-Data-Summary\",\"panelIndex\":11,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"},{\"col\":10,\"id\":\"Top-Combined-Summary\",\"panelIndex\":12,\"row\":5,\"size_x\":3,\"size_y\":2,\"type\":\"visualization\"}]",
                          "optionsJSON": "{\"darkTheme\":false}",
                          "uiStateJSON": "{\"P-10\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}},\"P-11\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}},\"P-12\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}},\"P-5\":{\"vis\":{\"legendOpen\":false}},\"P-6\":{\"vis\":{\"legendOpen\":false}},\"P-7\":{\"vis\":{\"legendOpen\":false}},\"P-8\":{\"vis\":{\"legendOpen\":false}},\"P-9\":{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}}",
                          "version": 1,
                          "timeRestore": "false",
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"filter\":[{\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"_index: batch-metadata\"}}}]}"
                          }
                        }
                      },
                      {
                        "_id": "Combined-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Combined Count",
                          "visState": "{\"title\":\"Combined Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Combined-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Combined Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Combined Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"*\"}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Combined-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Combined Size",
                          "visState": "{\"title\":\"Combined Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"*\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Published-Data-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Published Data Count",
                          "visState": "{\"title\":\"Published Data Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: publish\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Published-Data-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Published Data Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Published Data Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: publish\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Transformed-Datasets-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Transformed Dataset Size",
                          "visState": "{\"title\":\"Transformed Dataset Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: transformed\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Published-Data-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Published Data Size",
                          "visState": "{\"title\":\"Published Data Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: publish\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Raw-Size",
                        "_type": "visualization",
                        "_source": {
                          "title": "Raw Dataset Size",
                          "visState": "{\"title\":\"Raw Dataset Size\",\"type\":\"pie\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"isDonut\":false},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"sum\",\"schema\":\"metric\",\"params\":{\"field\":\"ContentLength\"}},{\"id\":\"2\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"segment\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type:raw\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Raw-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Raw Dataset Count",
                          "visState": "{\"title\":\"Raw Dataset Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type:raw\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Transformed-Datasets-Count",
                        "_type": "visualization",
                        "_source": {
                          "title": "Transformed Dataset Count",
                          "visState": "{\"title\":\"Transformed Dataset Count\",\"type\":\"histogram\",\"params\":{\"shareYAxis\":true,\"addTooltip\":true,\"addLegend\":true,\"legendPosition\":\"right\",\"scale\":\"linear\",\"mode\":\"stacked\",\"times\":[],\"addTimeMarker\":false,\"defaultYExtents\":false,\"setYExtents\":false,\"yAxis\":{}},\"aggs\":[{\"id\":\"1\",\"enabled\":true,\"type\":\"count\",\"schema\":\"metric\",\"params\":{}},{\"id\":\"2\",\"enabled\":true,\"type\":\"date_histogram\",\"schema\":\"segment\",\"params\":{\"field\":\"LastModified\",\"interval\":\"auto\",\"customInterval\":\"2h\",\"min_doc_count\":1,\"extended_bounds\":{}}},{\"id\":\"3\",\"enabled\":true,\"type\":\"terms\",\"schema\":\"group\",\"params\":{\"field\":\"Dataset.keyword\",\"size\":5,\"order\":\"desc\",\"orderBy\":\"1\"}}],\"listeners\":{}}",
                          "uiStateJSON": "{}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: transformed\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Transformed-Datasets-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Transformed Dataset Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Transformed Dataset Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"query\":\"_type: transformed\",\"analyze_wildcard\":true}},\"filter\":[]}"
                          }
                        }
                      },
                      {
                        "_id": "Top-Raw-Summary",
                        "_type": "visualization",
                        "_source": {
                          "title": "Top Raw Dataset Summary",
                          "visState": "{\"aggs\":[{\"enabled\":true,\"id\":\"1\",\"params\":{},\"schema\":\"metric\",\"type\":\"count\"},{\"enabled\":true,\"id\":\"2\",\"params\":{\"customLabel\":\"Dataset\",\"field\":\"Dataset.keyword\",\"order\":\"desc\",\"orderBy\":\"1\",\"size\":5},\"schema\":\"bucket\",\"type\":\"terms\"},{\"enabled\":true,\"id\":\"3\",\"params\":{\"customLabel\":\"Size (MB)\",\"field\":\"SizeMiB\"},\"schema\":\"metric\",\"type\":\"sum\"}],\"listeners\":{},\"params\":{\"perPage\":10,\"showMeticsAtAllLevels\":false,\"showPartialRows\":false,\"showTotal\":false,\"sort\":{\"columnIndex\":null,\"direction\":null},\"totalFunc\":\"sum\"},\"title\":\"Top Raw Dataset Summary\",\"type\":\"table\"}",
                          "uiStateJSON": "{\"vis\":{\"params\":{\"sort\":{\"columnIndex\":1,\"direction\":\"desc\"}}}}",
                          "description": "",
                          "version": 1,
                          "kibanaSavedObjectMeta": {
                            "searchSourceJSON": "{\"index\":\"batch-metadata\",\"query\":{\"query_string\":{\"analyze_wildcard\":true,\"query\":\"_type:raw\"}},\"filter\":[]}"
                          }
                        }
                      }
                    ]



def addDashboard(metadataFromBlob):
    try:
        elasticsearchIp=os.environ['esIp']
        print(elasticsearchIp)
        esClient = Elasticsearch(
            hosts=[{'host': elasticsearchIp, 'port': 9200}],
        )
        print(esClient);

        visualizations = json.dumps(batchDashboardJSON)
        #	print(batchDashboardJSON)
        for visualization in batchDashboardJSON:
            esClient.index(
                index='.kibana',
                doc_type=visualization['_type'],
                id=visualization['_id'],
                body=json.dumps(visualization['_source'])
            )
            print(visualization['_source'])
        # Set Default Index
        esClient.index(index='.kibana', doc_type='config', id='5.1.1',
                       body=json.dumps({'defaultIndex': 'batch-metadata'}))
        kibana_index_batch = {'title': batch_index, 'timeFieldName': 'LastModified'}
        esClient.index(index='.kibana', doc_type='index-pattern', id='batch-metadata',
                       body=json.dumps(kibana_index_batch))

        addDataToKibana(metadataFromBlob)

    except Exception as E:
        print("Unable to Create Index {0}".format("batch-metadata"))
        print(E)
        exit(4)

def addDataToKibana(dataFromBlob):
    elasticsearchIp=os.environ['esIp']
    esClient = Elasticsearch(
        hosts=[{'host': elasticsearchIp, 'port': 9200}]
    )


    print("^^^^^^^^^^^^^^^^^^^^^",dataFromBlob)
    
    result=esClient.index(index='batch-metadata',doc_type=dataFromBlob['DocType'], body=json.dumps(dataFromBlob))
    print(result)

#metadataFromBlob=json.loads(open(os.environ['req']).read())


eventData=str(open(os.environ['req']).read());
eventMSG=json.loads(eventData)
dataFromBlob=eventMSG[0]
print("DATAFROMBLOG:--",dataFromBlob['data']['url'])
url=dataFromBlob['data']['url'].split('/')
if (len(url)==7):
    print("URLLLLLLLLLL---",url)
    key=url[6]
    ContentType=dataFromBlob['data']['contentType']
    ETag=dataFromBlob['data']['eTag']
    ContentLength=dataFromBlob['data']['contentLength']
    metadata={}
    SizeMB=(dataFromBlob['data']['contentLength'])/(1024*1024)
    Dataset=url[5]
    docType=url[3]

    data={
        "Key": key,
        "ContentType": ContentType,
        "LastModified": dataFromBlob['eventTime'],
        "ContentLength": ContentLength,
        "metadata": metadata,
        "SizeMiB": SizeMB,
        "ETag": ETag,
        "Dataset": Dataset,
        "DocType":docType
    }
    if Dataset=="orders" or Dataset=="customers" or Dataset=="demographics" or Dataset=="products":
        addDashboard(data)
		
if (len(url)==6):
    print("URLLLLLLLLLL---",url)
    key=url[4]
    ContentType=dataFromBlob['data']['contentType']
    ETag=dataFromBlob['data']['eTag']
    ContentLength=dataFromBlob['data']['contentLength']
    metadata={}
    SizeMB=(dataFromBlob['data']['contentLength'])/(1024*1024)
    Dataset=url[4]
    docType=url[3]

    data={
        "Key": key,
        "ContentType": ContentType,
        "LastModified": dataFromBlob['eventTime'],
        "ContentLength": ContentLength,
        "metadata": metadata,
        "SizeMiB": SizeMB,
        "ETag": ETag,
        "Dataset": Dataset,
        "DocType":docType
    }
    if docType=="publish":
        addDashboard(data)


#print('*********'+str(open(os.environ['req']).read()))
# eventMSG=str(open(os.environ['req']).read());
# d=json.loads(eventMSG)
# print(type(json.loads(eventMSG)))
# print("******",d[0]['data'])
